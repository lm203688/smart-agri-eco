#!/bin/bash
# ==============================================================
# 农眼 AgriScreen —— 腾讯云 ECS 一键部署脚本
# 用法：解压后在本目录执行  bash deploy.sh
# 要求：ECS 已装 python3.10+ 和 pip3
# ==============================================================
set -e
cd "$(dirname "$0")"

echo "[1/4] 安装依赖..."
pip3 install -q -r requirements.txt || pip3 install -q --break-system-packages -r requirements.txt

echo "[2/4] 启动服务（后台守护，端口 8001）..."
if command -v systemctl >/dev/null 2>&1; then
  cat > /etc/systemd/system/agriscreen.service << EOF
[Unit]
Description=AgriScreen - Agriculture Investment Screening
After=network.target
[Service]
Type=simple
WorkingDirectory=$(pwd)
ExecStart=/usr/bin/env python3 -m uvicorn backend.server:app --host 0.0.0.0 --port 8001
Restart=always
RestartSec=3
[Install]
WantedBy=multi-user.target
EOF
  systemctl daemon-reload
  systemctl enable --now agriscreen
  echo "  systemd 服务已启动（开机自启）"
else
  nohup python3 -m uvicorn backend.server:app --host 0.0.0.0 --port 8001 > agri.log 2>&1 &
  echo "  nohup 后台启动完成（日志 agri.log）"
fi

echo "[3/4] 本机自检..."
sleep 3
if curl -s -o /dev/null -w "" http://127.0.0.1:8001/api/meta; then
  echo "  自检通过"
else
  echo "  自检失败，查看日志: journalctl -u agriscreen -n 50 或 cat agri.log"
  exit 1
fi

IP=$(curl -s -m 5 ifconfig.me 2>/dev/null || echo "服务器IP")
echo "[4/4] 部署完成"
echo ""
echo "  访问地址: http://${IP}:8001"
echo "  注意：请到腾讯云控制台-安全组-添加入站规则 TCP 8001 端口"
echo ""
echo "  可选 LLM 增强（配好 GLM key 后提取更智能）:"
echo "    echo 'export ZHIPU_API_KEY=你的key' >> ~/.bashrc && source ~/.bashrc && systemctl restart agriscreen"
