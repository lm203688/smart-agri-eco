// 农眼 AgriScreen 前端逻辑：三幕式单页流
const $ = (s) => document.querySelector(s);
let pickedFiles = [];

/* ---------- 通用 ---------- */
function show(scene) {
  for (const s of document.querySelectorAll(".scene")) s.hidden = true;
  $(scene).hidden = false;
}
function fmtA(v) {
  if (v == null) return "—";
  if (Math.abs(v) >= 1e8) return (v / 1e8).toFixed(2) + " 亿";
  if (Math.abs(v) >= 1e4) return (v / 1e4).toFixed(1) + " 万";
  return String(Math.round(v));
}

/* ---------- 第①幕 ---------- */
async function initHome() {
  try {
    const m = await (await fetch("/api/meta")).json();
    $("#meta-version").textContent = m.rules_version;
    $("#meta-cases").textContent = m.case_count + " 个";
    $("#meta-llm").textContent = m.llm;
  } catch (e) {}
  try {
    const r = await (await fetch("/api/assess/list")).json();
    if (r.items && r.items.length) {
      $("#recent").hidden = false;
      $("#recent-list").innerHTML = r.items.slice(0, 5).map((i) => {
        const g = i.grade ? `<span class="badge ${i.grade === "通过" ? "verified" : i.grade === "淘汰" ? "not_found" : "unverified"}">${i.grade}</span>` : "";
        return `<div class="recent-item" onclick="openReport('${i.id}')"><span class="co">${esc(i.company)}</span>
                <span>${i.score ? Math.round(i.score) + " 分" : "进行中"} ${g}</span></div>`;
      }).join("");
    }
  } catch (e) {}
}
const esc = (s) => String(s || "").replace(/[<>&"]/g, (c) => ({"<": "&lt;", ">": "&gt;", "&": "&amp;", '"': "&quot;"}[c]));

const dz = $("#dropzone");
dz.addEventListener("click", (e) => { if (e.target.closest("#btn-pick")) return; $("#file-input").click(); });
$("#btn-pick").onclick = (e) => { e.stopPropagation(); $("#file-input").click(); };
$("#file-input").onchange = (e) => setFiles(e.target.files);
["dragover", "dragenter"].forEach((ev) => dz.addEventListener(ev, (e) => { e.preventDefault(); dz.classList.add("dragover"); }));
["dragleave", "drop"].forEach((ev) => dz.addEventListener(ev, (e) => { e.preventDefault(); dz.classList.remove("dragover"); }));
dz.addEventListener("drop", (e) => setFiles(e.dataTransfer.files));

function setFiles(fl) {
  pickedFiles = [...fl];
  if (!pickedFiles.length) return;
  $(".dz-title").textContent = `已选 ${pickedFiles.length} 个文件`;
  $(".dz-sub").innerHTML = pickedFiles.map((f) => esc(f.name)).join(" · ");
  $("#btn-start").disabled = false;
}
$("#btn-start").onclick = startAssess;

async function startAssess() {
  const fd = new FormData();
  pickedFiles.forEach((f) => fd.append("files", f));
  fd.append("company", $("#company-input").value.trim());
  const r = await (await fetch("/api/assess", { method: "POST", body: fd })).json();
  if (!r.id) return alert("创建失败");
  showFlow(r.id, $("#company-input").value.trim() || "未命名");
}

/* ---------- 第②幕 ---------- */
const STAGE_ICONS = ["🗂", "📖", "🔍", "⚖", "🕳", "🎯", "🛡", "🧮", "📝"];
let pollTimer = null;

function showFlow(aid, company) {
  show("#scene-flow");
  $("#flow-company").textContent = company;
  const stages = ["L0 归档", "L1 解析", "L2 提取", "L3 归一化", "L4 缺口检测", "L5 分类", "L6 公开核验", "L7 评分", "L8 报告生成"];
  $("#stage-list").innerHTML = stages.map((s, i) => `
    <div class="stage-row" id="st-${i}"><div class="stage-dot">${STAGE_ICONS[i]}</div>
    <div class="stage-body"><div class="stage-name">${s}</div><div class="stage-detail" id="sd-${i}"></div></div></div>`).join("");
  $("#flow-log").innerHTML = "";
  pollTimer = setInterval(async () => {
    try {
      const d = await (await fetch(`/api/assess/${aid}`)).json();
      const idx = d.stage_idx ?? 0;
      d.stages.forEach((_, i) => {
        const row = $(`#st-${i}`);
        if (!row) return;
        row.classList.toggle("done", i < idx);
        row.classList.toggle("active", i === idx);
      });
      if (d.stage && d.stage.detail) {
        const sd = $(`#sd-${idx}`);
        if (sd) sd.textContent = d.stage.detail;
        if (d.stage.stage) log(`[${d.stage.stage}] ${d.stage.detail}`);
      }
      if (d.status === "done") { clearInterval(pollTimer); openReport(aid); }
      if (d.status === "error") { clearInterval(pollTimer); log(`❌ 出错：${d.stage?.detail || "未知错误"}`); }
      if (d.status === "need_classify") {
        clearInterval(pollTimer);
        const rep = await (await fetch(`/api/assess/${aid}/report`)).json();
        showClassifyModal(aid, rep);
      }
    } catch (e) {}
  }, 900);
}
function log(msg) {
  const el = $("#flow-log");
  el.innerHTML += esc(msg) + "\n";
  el.scrollTop = el.scrollHeight;
}

/* 分类确认弹层 */
let selCat = null;
function showClassifyModal(aid, rep) {
  const cls = rep.cls || {};
  $("#classify-reason").textContent = cls.reason || "未能自动识别分类";
  fetch("/api/meta").then((r) => r.json()).then((m) => {
    const ids = ["seeds", "agmach", "digag", "bioinputs", "supply", "livestock"];
    $("#cat-grid").innerHTML = ids.map((id, i) => `<div class="cat-opt" data-cat="${id}">${m.categories[i] || id}</div>`).join("");
    $("#cat-grid").querySelectorAll(".cat-opt").forEach((el) => {
      el.onclick = () => {
        $("#cat-grid").querySelectorAll(".cat-opt").forEach((x) => x.classList.remove("sel"));
        el.classList.add("sel"); selCat = el.dataset.cat;
        $("#btn-confirm-cat").disabled = false;
      };
    });
  });
  $("#classify-modal").hidden = false;
  $("#btn-confirm-cat").onclick = async () => {
    const fd = new FormData();
    fd.append("category", selCat);
    await fetch(`/api/assess/${aid}/confirm`, { method: "POST", body: fd });
    $("#classify-modal").hidden = true;
    showFlow(aid, rep.company || "评估中");
  };
}

/* ---------- 第③幕 报告 ---------- */
let REPORT = null, AID = null;
async function openReport(aid) {
  AID = aid;
  const r = await (await fetch(`/api/assess/${aid}/report`)).json();
  if (r.error) return alert("报告尚未就绪");
  if (r.status === "need_classify") return showClassifyModal(aid, r);
  REPORT = r;
  show("#scene-report");
  renderReport();
}

function renderReport() {
  const r = REPORT, n = r.block_extract.normalized, bv = r.block_verdict;
  const v = bv.verdict || "NONE";
  let h = "";
  /* ① 档案树 */
  const files = r.block_files.files || [];
  h += `<div class="block"><div class="block-title">${r.block_files.title}</div>
        <div style="font-size:13px;margin-bottom:8px">共 ${files.length} 个文件 · 主数据源 ${r.block_files.primary?.length || 0} 个 · 核验源 ${r.block_files.verify?.length || 0} 个</div>
        ${files.map((f) => `<div class="bench-chip" style="margin-bottom:6px">${esc(f.role_name || f.role || "文件")}：${esc(f.filename)} ${f.status === "error" ? "⚠ 解析失败" : ""}</div>`).join("")}
        ${(r.block_files.conflicts || []).map((c) => `<div class="conflict-box">⚠ <b>数据冲突</b>：「${c.field}」跨文件差异 ${c.deviation_pct}%（${Object.entries(c.values).map(([k, x]) => `${esc(k)}:${x}`).join(" / ")}）——按更可信来源计分，差异计入收入质量</div>`).join("")}</div>`;
  /* ② 结论卡 */
  h += `<div class="verdict-card ${v}"><div class="verdict-word">${bv.verdict_name}</div>
        <div class="verdict-score">总分 ${bv.total ?? "—"}${bv.total_range ? `（区间 ${bv.total_range[0]}–${bv.total_range[1]}）` : ""}</div>
        <div class="verdict-reason">${esc(bv.verdict_reason || "")}</div>
        <div class="verdict-meta"><span>分类：${esc(bv.category_name)}</span><span>置信度 ${Math.round(bv.category_confidence || 0)}%</span>
        <span>规则 ${esc(r.rules_version)}</span><span>生成于 ${esc(r.generated_at || "")}</span></div></div>`;
  /* ③ 决策路径 */
  h += `<div class="block"><div class="block-title">${r.block_path.title}</div>
        ${r.block_path.items.map((p) => `<div class="path-item ${p.type === "一票否决" ? "veto" : p.type === "五闸爆雷" ? "gate" : ""}">
        <span class="pi-type">【${p.type}】</span>${esc(p.name)}<br>${esc(p.detail)}${p.impact ? `<br><span style="color:var(--grey)">→ ${esc(p.impact)}</span>` : ""}</div>`).join("")}
        ${r.block_path.counterfactual ? `<div class="cf-box">🔄 <b>反事实边界</b>：${esc(r.block_path.counterfactual.text || "")}</div>` : ""}</div>`;
  /* ④ 五闸 */
  h += `<div class="block"><div class="block-title">${r.block_gates.title}</div>
        ${r.block_gates.fired && r.block_gates.fired.length
          ? r.block_gates.fired.map((g) => `<div class="gate-item"><span class="gate-name">⚠ ${esc(g.name)}</span>：${esc(g.message || g.note || "")}</div>`).join("")
          : `<div style="font-size:13px;color:var(--pass)">✓ 全部通过（现金收入比 ${n.cash_ratio ?? "—"}% / 客户集中 ${n.top5_client_pct ?? "—"}% / 毛利率 ${n.gross_margin ?? "—"}% / 单位经济 ${n.ue_margin ?? "—"}% / 跑道 ${n.runway_months ?? "—"} 月）</div>`}</div>`;
  /* ⑤ 评分卡 */
  h += `<div class="block"><div class="block-title">${r.block_card.title}</div>
        ${r.block_card.dimensions.map((d) => `<div class="dim-row"><div class="dim-head"><span class="dn">${esc(d.name)}（权重 ${d.weight}%）</span><span>${d.score ?? "缺数据·降权"}</span></div>
        <div class="dim-bar"><div class="dim-fill" style="width:${d.score || 0}%;background:${(d.score ?? 0) >= 70 ? "var(--pass)" : (d.score ?? 0) >= 45 ? "var(--dig)" : "var(--fail)"}"></div></div></div>`).join("")}
        ${r.block_card.missing?.length ? `<div style="font-size:12px;color:var(--grey)">缺失维度：${r.block_card.missing.map(esc).join("、")}（已降权，总分以区间表示）</div>` : ""}</div>`;
  /* ⑥ 对标 */
  h += `<div class="block"><div class="block-title">${r.block_bench.title}</div><div class="bench-row">
        ${r.block_bench.benchmarks.map((b) => `<div class="bench-chip">${esc(b.name)}<br>毛利率 <b>${b.gross_margin ?? "—"}%</b> ${b.pe ? `PE ${b.pe}x` : ""}${b.ps ? `PS ${b.ps}x` : ""}</div>`).join("")}
        <div class="bench-chip" style="border-color:var(--green)"><b>本项目</b><br>毛利率 <b>${n.gross_margin ?? "—"}%</b></div></div>
        <div style="font-size:12px;color:var(--grey)">${esc(r.block_bench.bench_names?.join("、") || "")} · 估值参考：${esc(Object.values(r.block_card?.valuation_hint || r.block_verdict?.valuation_hint || { v: "" })[0] || "")}</div></div>`;
  /* ⑦ 核验 */
  h += `<div class="block"><div class="block-title">${r.block_verify.title}</div>
        ${r.block_verify.results.length ? r.block_verify.results.map((x) => `<div class="bench-chip" style="margin-bottom:6px">${esc(x.type)}：${esc(x.value)} <span class="badge ${x.status}">${x.status === "verified" ? "已核实" : x.status === "unverified" ? "待人工复核" : "未发现"}</span>${x.note ? `<br><span style="font-size:11px;color:var(--grey)">${esc(x.note)}</span>` : ""}</div>`).join("") : "<div style='font-size:13px;color:var(--grey)'>本分类无强制核验项</div>"}</div>`;
  /* ⑧ 缺口+补数 */
  const g = r.block_gaps.gaps || {};
  const gi = [["fatal", "致命缺（无法给结论）"], ["critical", "重要缺（影响精度）"], ["normal", "一般缺（已标注）"]];
  let gapHtml = "";
  gi.forEach(([lv, name]) => {
    Object.entries(g[lv] || {}).forEach(([f, hint]) => {
      gapHtml += `<div class="gap-item ${lv}"><b>${name} · ${f}</b><div class="gap-hint">${esc(hint)}</div></div>`;
    });
  });
  h += `<div class="block"><div class="block-title">${r.block_gaps.title}</div>
        ${gapHtml || "<div style='font-size:13px;color:var(--pass)'>✓ 关键数据齐全</div>"}
        <div class="supp-zone" id="supp-zone">📥 点此补传数据（拍照也行）——补充后自动增量重算<input type="file" id="supp-input" multiple></div>
        ${r.supplement_diff ? `<div class="diff-box">📈 补数后：${esc(r.supplement_diff.old_total)} → <b>${esc(r.supplement_diff.new_total)}</b> 分（新增：${r.supplement_diff.fields_added.map(esc).join("、") || "无"}）</div>` : ""}</div>`;
  /* ⑨ 深挖清单 */
  h += `<div class="block"><div class="block-title">${r.block_dd.title}</div>
        ${r.block_dd.items.map((i) => `<div class="dd-item">${esc(i)}</div>`).join("") || "<div style='font-size:13px;color:var(--grey)'>—</div>"}</div>`;
  /* ⑩ 提取明细 */
  const rows = Object.entries(n).filter(([k, v]) => v != null && !k.startsWith("_"));
  h += `<div class="block"><div class="block-title">${r.block_extract.title}</div><table class="t">
        <tr><th>字段</th><th>值</th></tr>${rows.map(([k, v]) => `<tr><td>${k}</td><td>${typeof v === "number" ? (Math.abs(v) >= 1e4 && /revenue|profit|cash|burn|amount|arr/.test(k) ? fmtA(v) + " 元" : Math.round(v * 100) / 100) : esc(v)}</td></tr>`).join("")}</table>
        <div style="font-size:11px;color:var(--grey);margin-top:8px">提取通道：${esc(r.llm_mode || "")} · 数值均带来源页码（生产版支持点击徽标跳转原文）</div></div>`;
  /* ⑪ 免责 */
  h += `<div class="block"><div class="block-title">${r.block_meta.title}</div>
        <div style="font-size:12px;color:var(--grey);line-height:1.8">${esc(r.block_meta.disclaimer)}<br>规则版本 ${esc(r.block_meta.rules_version)} · 案例库 ${r.block_meta.case_count} 例 · 报告编号 ${esc(r.report_id)}</div></div>`;

  $("#report-body").innerHTML = h;
  const sz = $("#supp-zone");
  if (sz) {
    sz.onclick = () => $("#supp-input").click();
    $("#supp-input").onchange = async (e) => {
      const fd = new FormData();
      [...e.target.files].forEach((f) => fd.append("files", f));
      const resp = await (await fetch(`/api/assess/${AID}/supplement`, { method: "POST", body: fd })).json();
      if (resp.ok) { await openReport(AID); chatSay("已收到补充资料，增量重算完成。看「数据缺口」区块的 diff。"); }
    };
  }
}

/* ---------- 对话栏（基于报告数据的可追溯问答） ---------- */
function chatSay(text) {
  $("#chat-log").innerHTML += `<div class="chat-msg ai">${text}</div>`;
  $("#chat-log").scrollTop = 1e9;
}
function userSay(q) {
  $("#chat-log").innerHTML += `<div class="chat-msg user">${esc(q)}</div>`;
  $("#chat-log").scrollTop = 1e9;
}
async function answer(q) {
  const r = REPORT; if (!r) return;
  const bv = r.block_verdict, n = r.block_extract.normalized;
  if (/结论|为什么|判断/.test(q)) {
    const top = (r.block_path.items || []).slice(0, 3).map((p) => `<b>${p.name}</b>：${p.detail}`).join("<br>");
    chatSay(`结论是「<b>${bv.verdict_name}</b>」（${bv.total} 分）。决定因素按影响排序：<br>${top}`);
  } else if (/风险|雷|担心/.test(q)) {
    const gates = (r.block_gates.fired || []).map((g) => `⚠ <b>${g.name}</b>：${g.message || ""}`).join("<br>");
    chatSay(gates ? `爆雷项如下：<br>${gates}` : `本次五闸全部通过，未触发红线。重点风险见「深挖清单」——那是进入尽调后必问的问题。`);
  } else if (/翻档|提升|升级|怎么才能/.test(q)) {
    chatSay(r.block_path.counterfactual?.text ? `🔄 ${r.block_path.counterfactual.text}` : "当前数据不足以计算翻档边界。");
  } else if (/缺|数据|补充/.test(q)) {
    const g = r.block_gaps.gaps || {};
    const items = Object.entries(g.fatal || {}).concat(Object.entries(g.critical || {}));
    chatSay(items.length ? `缺失字段 ${items.length} 个：<br>` + items.slice(0, 5).map(([f, hint]) => `<b>${f}</b>：${hint}`).join("<br>") : "关键数据齐全，无致命缺口。");
  } else if (/毛利|收入|现金|跑道|客户/.test(q)) {
    const k = /毛利/.test(q) ? "gross_margin" : /收入/.test(q) ? "revenue" : /跑道/.test(q) ? "runway_months" : /客户/.test(q) ? "top5_client_pct" : "cash_balance";
    chatSay(`「${k}」当前提取值：<b>${n[k] ?? "缺失"}</b>。该值来自上传文件（可追溯来源页码），评分卡中对应维度得分见「⑤ 评分卡」区块。若数字有误，可在补充区上传正确资料，系统会增量重算。`);
  } else {
    chatSay(`这个问题与报告数据相关部分：当前结论 <b>${bv.verdict_name}</b> / 总分 ${bv.total}。更细的问题（如某个字段口径）请指明字段名，例如「毛利率怎么算的」。`);
  }
}
$("#btn-chat").onclick = () => { const q = $("#chat-input").value.trim(); if (q) { userSay(q); $("#chat-input").value = ""; answer(q); } };
$("#chat-input").addEventListener("keydown", (e) => { if (e.key === "Enter") $("#btn-chat").click(); });
document.querySelectorAll(".chip").forEach((c) => c.onclick = () => { userSay(c.dataset.q); answer(c.dataset.q); });

initHome();
