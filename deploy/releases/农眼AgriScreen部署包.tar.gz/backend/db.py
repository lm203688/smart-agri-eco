# -*- coding: utf-8 -*-
"""三库分离存储：案例库 / 评估记录库 / 规则版本库（SQLite 实现）"""
import sqlite3, json, time, os

DB_PATH = os.path.join(os.path.dirname(__file__), "..", "data", "cases.db")


def _conn():
    d = os.path.dirname(DB_PATH)
    os.makedirs(d, exist_ok=True)
    c = sqlite3.connect(DB_PATH)
    c.row_factory = sqlite3.Row
    return c


SCHEMA = """
CREATE TABLE IF NOT EXISTS rule_versions(
  version TEXT PRIMARY KEY, released TEXT, notes TEXT, active INTEGER DEFAULT 0
);
CREATE TABLE IF NOT EXISTS cases(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT, category TEXT, is_benchmark INTEGER DEFAULT 0,
  metrics TEXT, outcome TEXT, source TEXT,
  data_quality TEXT DEFAULT 'ok', created REAL
);
CREATE TABLE IF NOT EXISTS assessments(
  id TEXT PRIMARY KEY,
  company_name TEXT DEFAULT '',
  files TEXT DEFAULT '[]',
  rules_version TEXT,
  status TEXT DEFAULT 'running',
  stage TEXT,
  category TEXT,
  category_confidence REAL,
  category_confirmed_by_user INTEGER DEFAULT 0,
  score REAL, grade TEXT,
  report TEXT,
  created REAL,
  finished REAL
);
CREATE TABLE IF NOT EXISTS supplement_files(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  assess_id TEXT, filename TEXT, parsed TEXT, created REAL
);
"""


def init_db():
    c = _conn()
    c.executescript(SCHEMA)
    c.commit()
    c.close()


def execute(sql, params=()):
    c = _conn()
    c.execute(sql, params)
    c.commit()
    c.close()


def _active_version():
    c = _conn()
    r = c.execute("SELECT version FROM rule_versions WHERE active=1 ORDER BY released DESC LIMIT 1").fetchone()
    c.close()
    return r["version"] if r else "v0"


def _now_iso():
    import datetime
    return datetime.datetime.now().strftime("%Y-%m-%d %H:%M")


def create_assessment(aid, company, files):
    c = _conn()
    c.execute("INSERT INTO assessments(id, company_name, files, rules_version, status, stage, created) VALUES(?,?,?,?,?,?,?)",
              (aid, company or "", json.dumps(files, ensure_ascii=False), _active_version(),
               "running", json.dumps({"idx": -2, "stage": "排队中", "detail": ""}, ensure_ascii=False), time.time()))
    c.commit()
    c.close()


def update_stage(aid, idx, detail_json):
    """idx: 0-8 流水线阶段；-1 error"""
    c = _conn()
    status = "error" if idx == -1 else None
    if status:
        c.execute("UPDATE assessments SET stage=?, status=? WHERE id=?", (detail_json, status, aid))
    else:
        c.execute("UPDATE assessments SET stage=? WHERE id=?", (detail_json, aid))
    c.commit()
    c.close()


def set_report(aid, report_json, status=None, score=None, grade=None, category=None, confidence=None):
    c = _conn()
    sets, vals = ["report=?"], [report_json]
    if status is not None:
        sets.append("status=?"); vals.append(status)
    if score is not None:
        sets.append("score=?"); vals.append(score)
    if grade is not None:
        sets.append("grade=?"); vals.append(grade)
    if category is not None:
        sets.append("category=?"); vals.append(category)
    if confidence is not None:
        sets.append("category_confidence=?"); vals.append(confidence)
    if status in ("done",):
        sets.append("finished=?"); vals.append(time.time())
    vals.append(aid)
    c.execute(f"UPDATE assessments SET {', '.join(sets)} WHERE id=?", vals)
    c.commit()
    c.close()


def get_assessment(aid):
    c = _conn()
    r = c.execute("SELECT * FROM assessments WHERE id=?", (aid,)).fetchone()
    c.close()
    return dict(r) if r else None


def list_assessments(limit=30):
    c = _conn()
    rows = c.execute("SELECT id, company_name, category, score, grade, status, created FROM assessments ORDER BY created DESC LIMIT ?",
                     (limit,)).fetchall()
    c.close()
    return [dict(r) for r in rows]


def add_supplement(aid, filename, parsed):
    c = _conn()
    c.execute("INSERT INTO supplement_files(assess_id, filename, parsed, created) VALUES(?,?,?,?)",
              (aid, filename, json.dumps(parsed, ensure_ascii=False), time.time()))
    c.commit()
    c.close()


def all_cases():
    c = _conn()
    rows = c.execute("SELECT * FROM cases").fetchall()
    c.close()
    return [dict(r) for r in rows]


def insert_case(name, category, metrics, outcome="verified", is_benchmark=0, source="seed"):
    c = _conn()
    c.execute("INSERT INTO cases(name, category, is_benchmark, metrics, outcome, source, created) VALUES(?,?,?,?,?,?,?)",
              (name, category, is_benchmark, json.dumps(metrics, ensure_ascii=False), outcome, source, time.time()))
    c.commit()
    c.close()
