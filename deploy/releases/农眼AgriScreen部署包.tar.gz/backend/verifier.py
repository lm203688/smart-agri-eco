# -*- coding: utf-8 -*-
"""
L6 公开核验（登记证/审定/环评）：MVP 内置本地登记库模拟公开数据库查询。
生产版接农业农村部品种审定公告（种业管理司）与中国农药信息网（chinapesticide.org.cn）。
核验结果分三档：verified（本地库命中）/ unverified（未查到，需人工）/ not_found
"""
from .rules import CATEGORIES

# 企业/项目名 → 已登记证照（MVP 演示库；生产版换真实公开数据源接口）
LOCAL_REGISTRY = {
    # 审定品种（种业管理司公告格式：品种名+审定编号）
    "审定": ["金玉188", "郑单958", "中科玉505", "裕丰303", "登海605", "先玉335", "隆平206"],
    # 农药/肥料登记证号段（中国农药信息网格式：PD20xx-xxxx / 农肥准字）
    "登记": ["PD20250012", "PD20241137", "微生物菌剂2025-0210", "农肥准字2025-3571"],
    # 安全证书（农业转基因生物安全证书编号格式）
    "安全证书": ["农基安证字(2025)第011号", "农基安证字(2024)第052号"],
}


def verify(normalized: dict, all_text: str, category: str) -> list:
    """对分类特异证照做核验：提取文本中的证照编号 → 与登记库比对"""
    results = []
    if category == "seeds":
        for kw in ["审定", "品种审定"]:
            for name in LOCAL_REGISTRY["审定"]:
                if name in all_text:
                    results.append({"type": "审定品种", "value": name, "status": "verified",
                                    "source": "农业农村部品种审定公告（内置镜像库）"})
        for cert in LOCAL_REGISTRY["安全证书"]:
            if cert in all_text:
                results.append({"type": "安全证书", "value": cert, "status": "verified",
                                "source": "农业转基因生物安全证书公告（内置镜像库）"})
        # 声称有审定但文本无具体品种名
        if ("审定" in all_text and not any(r["type"] == "审定品种" for r in results)):
            results.append({"type": "审定品种", "value": "声称有审定品种，未提供可核验编号",
                            "status": "unverified", "source": "-", "note": "深挖清单必问项：索取审定编号并在官方库复核"})
    if category == "bioinputs":
        for cert in LOCAL_REGISTRY["登记"]:
            if cert in all_text:
                results.append({"type": "农药/肥料登记证", "value": cert, "status": "verified",
                                "source": "中国农药信息网（内置镜像库）"})
        if normalized.get("reg_certs") and not any(r["type"] == "农药/肥料登记证" for r in results):
            results.append({"type": "农药/肥料登记证", "value": f"声称 {int(normalized['reg_certs'])} 张，未提供编号",
                            "status": "unverified", "source": "-", "note": "索取登记证编号并在中国农药信息网复核"})
    if category == "livestock":
        has_eia = normalized.get("eia_passed") or "环评" in all_text
        results.append({"type": "环评批复", "value": "文本出现环评表述" if has_eia else "未发现环评材料",
                        "status": "unverified" if has_eia else "not_found",
                        "source": "-", "note": "养殖类必验：环评批复文号（生态环境部门公示系统可查）"})
    return results


def verify_text_certs(all_text: str) -> list:
    return verify({}, all_text, "seeds") + verify({}, all_text, "bioinputs")
