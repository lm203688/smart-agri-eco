# -*- coding: utf-8 -*-
"""LLM 网关：OpenAI 兼容协议（GLM/DeepSeek/Qwen 均可）。无 key 自动降级纯正则模式。"""
import os, json

# 环境变量二选一：LLM_API_KEY（兼容端点）；缺省尝试 ZHIPU_API_KEY / OPENAI_API_KEY
_API_KEY = os.environ.get("LLM_API_KEY") or os.environ.get("ZHIPU_API_KEY") or os.environ.get("OPENAI_API_KEY")
_BASE_URL = os.environ.get("LLM_BASE_URL", "https://open.bigmodel.cn/api/paas/v4")
_MODEL = os.environ.get("LLM_MODEL", "glm-4-flash")


def llm_available() -> bool:
    return bool(_API_KEY)


def llm_extract_fields(docs: list, fields: list = None) -> dict:
    """
    通道B：把文档文本交给 LLM，要求 JSON 输出指定字段。
    失败静默返回 {}（由通道A兜底）。docs: [{filename, text}]
    """
    if not llm_available():
        return {}
    try:
        import httpx
        field_list = fields or [
            "revenue", "gross_margin", "gross_profit", "net_profit", "cash_balance", "cash_received",
            "monthly_burn", "revenue_prev", "revenue_growth", "top5_client_pct", "subsidy_pct",
            "ue_margin", "runway_months", "approved_varieties", "safety_certs", "reg_certs",
            "pipeline_certs", "units_sold", "arr_ratio", "renewal_rate", "store_count", "output_volume"]
        prompt = (
            "你是财务数据抽取器。从下列公司资料文本中提取字段，只输出 JSON（无其他文字），"
            "字段缺失时值设为 null，金额统一为元（数字），比率为百分数数值：\n"
            + "\n".join(f["filename"] + ":\n" + f["text"][:8000] for f in docs)
            + "\n输出字段：" + ", ".join(field_list)
        )
        r = httpx.post(_BASE_URL + "/chat/completions", timeout=60,
                       headers={"Authorization": f"Bearer {_API_KEY}"},
                       json={"model": _MODEL, "messages": [{"role": "user", "content": prompt}],
                             "temperature": 0.1})
        content = r.json()["choices"][0]["message"]["content"]
        content = content.strip().removeprefix("```json").removesuffix("```").strip()
        data = json.loads(content)
        out = {}
        for k, v in data.items():
            if isinstance(v, (int, float)):
                out[k] = v
        return out
    except Exception:
        return {}
