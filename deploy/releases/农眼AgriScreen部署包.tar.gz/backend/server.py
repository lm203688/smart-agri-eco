# -*- coding: utf-8 -*-
"""
FastAPI 服务：三幕式产品形态的服务端编排
POST /api/assess          上传一堆文件（L0 归档 → 流水线）
GET  /api/assess/{id}     阶段流进度（第②幕轮询）
GET  /api/assess/{id}/report   完整报告（第③幕）
POST /api/assess/{id}/confirm 分类人工确认
POST /api/assess/{id}/supplement  补数上传（增量重算）
GET  /api/assess/list     首页最近评估
GET  /api/meta            规则版本/案例数
"""
import os, uuid, json, time, shutil, threading
from fastapi import FastAPI, UploadFile, File, Form
from fastapi.staticfiles import StaticFiles
from fastapi.responses import JSONResponse
from . import db, rules, parser, archiver, extractor, classifier, verifier, gap, scorer, report as report_builder
from .seed_cases import seed

app = FastAPI(title="农眼 AgriScreen——农业项目投资初筛系统", version="1.0.0")
UPLOAD_DIR = os.path.join(os.path.dirname(__file__), "..", "data", "uploads")
os.makedirs(UPLOAD_DIR, exist_ok=True)


@app.on_event("startup")
def startup():
    db.init_db()
    db.execute("INSERT OR IGNORE INTO rule_versions(version, released, notes, active) VALUES(?,?,?,1)",
               (rules.RULES_VERSION, rules.RELEASED, "首版：六分类/五闸/六评分卡"))
    seed()
    print(f"[农眼] rules {rules.RULES_VERSION} | cases {len(db.all_cases())}")


STAGES = ["L0 归档", "L1 解析", "L2 提取", "L3 归一化", "L4 缺口检测", "L5 分类",
          "L6 公开核验", "L7 评分", "L8 报告生成"]


# ---------- 流水线（同步执行，阶段进度写库供轮询） ----------
def _set_stage(aid, idx, detail=""):
    db.update_stage(aid, idx, json.dumps({"idx": idx, "stage": STAGES[idx] if isinstance(idx, int) and 0 <= idx < len(STAGES) else "处理中",
                                          "detail": detail}, ensure_ascii=False))


def _pipeline(aid: str, saved: list, company: str):
    try:
        # ---- L0 归档 ----
        _set_stage(aid, 0, f"识别 {len(saved)} 个文件的角色")
        parsed = []
        for f in saved:
            pf = parser.parse_file(f["path"], f["filename"])
            f["error"] = pf.error
            parsed.append(pf)
        tree, primary, verify_files = archiver.archive([{"filename": p.filename, "ftype": p.ftype, "parsed": p} for p in parsed])
        conflict_checks = {}
        _set_stage(aid, 1, f"解析 {len([p for p in parsed if not p.error])} 个可读文件")
        all_text = "\n".join(parser.full_text(p) for p in parsed if not p.error)
        # ---- L2 提取（双通道） ----
        _set_stage(aid, 2, "双通道提取财务与管线字段")
        primary_files = [{"filename": f["filename"], "parsed": f["parsed"]} for f in primary]
        extracted, per_file_extracted = extractor.extract(primary_files)
        cross_flags = {k: v["dual_check"] for k, v in extracted.items() if isinstance(v, dict) and v.get("dual_check")}
        _set_stage(aid, 3, "归一化单位/口径/派生指标")
        n = extractor.normalize(extracted)
        # ---- L4 缺口 ----
        _set_stage(aid, 4, "检测关键数据缺口")
        # ---- L5 分类 ----
        _set_stage(aid, 5, "六分类识别")
        cls = classifier.classify(all_text, n)
        category = cls["category"]
        if category is None:
            db.set_report(aid, json.dumps({"status": "need_classify", "cls": cls,
                                           "n": n, "files": [f["filename"] for f in saved]}, ensure_ascii=False),
                          status="need_classify")
            db.update_stage(aid, 8, json.dumps({"idx": 8, "stage": "等待人工分类", "detail": cls["reason"]}, ensure_ascii=False))
            return
        # ---- L6 核验 ----
        _set_stage(aid, 6, f"核验 {rules.CATEGORIES[category]['name']} 证照")
        verify_results = verifier.verify(n, all_text, category)
        # ---- L4 缺口（分类后按卡字段） ----
        gaps = gap.detect(n, category)
        conflicts = archiver.detect_conflicts(per_file_extracted)
        # ---- L7 评分 ----
        _set_stage(aid, 7, "五闸 → 评分卡 → 否决检查")
        evaluation = scorer.evaluate(category, n)
        # ---- L8 报告 ----
        _set_stage(aid, 8, "生成统一格式报告")
        rep = report_builder.build_report(aid, company, category, cls, n, evaluation, gaps,
                                           {"tree": tree, "primary": [p["filename"] for p in primary],
                                            "verify": [v["filename"] for v in verify_files]},
                                           verify_results, conflicts,
                                           [{"filename": f["filename"], "role": f.get("role", ""),
                                             "role_name": f.get("role_name", ""), "status": f.get("status", "")} for f in tree])
        rep["cross_flags"] = cross_flags
        rep["llm_mode"] = "llm+regex 双通道" if extractor.llm_available() and cross_flags is not None else ("llm+regex 双通道" if extractor.llm_available() else "regex 单通道（未配置 LLM_API_KEY，降级模式）")
        db.set_report(aid, json.dumps(rep, ensure_ascii=False))
        db.execute("UPDATE assessments SET score=?, grade=?, category=?, category_confidence=?, status='done' WHERE id=?",
                   (evaluation["card"]["total"], evaluation["verdict_name"], category, cls.get("confidence"), aid))
        files_meta = [{"filename": f["filename"], "role": f.get("role", ""), "role_name": f.get("role_name", "")} for f in tree]
        db.execute("UPDATE assessments SET files=? WHERE id=?", (json.dumps(files_meta, ensure_ascii=False), aid))
    except Exception as e:
        import traceback
        db.update_stage(aid, -1, json.dumps({"stage": "error", "detail": str(e), "trace": traceback.format_exc()[-500:]}, ensure_ascii=False))


@app.post("/api/assess")
async def assess(files: list[UploadFile] = File(...), company: str = Form("")):
    aid = uuid.uuid4().hex[:12]
    dp = os.path.join(UPLOAD_DIR, aid)
    os.makedirs(dp, exist_ok=True)
    saved = []
    for f in files:
        path = os.path.join(dp, f.filename)
        with open(path, "wb") as out:
            shutil.copyfileobj(f.file, out)
        saved.append({"path": path, "filename": f.filename})
    db.create_assessment(aid, company or "", [f["filename"] for f in saved])
    db.update_stage(aid, 0, json.dumps({"stage": STAGES[0], "detail": "排队中"}, ensure_ascii=False))
    threading.Thread(target=_pipeline, args=(aid, saved, company), daemon=True).start()
    return {"id": aid}


@app.get("/api/assess/list")
def ls():
    rows = db.list_assessments()
    return {"items": [{"id": r["id"], "company": r["company_name"] or "未命名", "grade": r["grade"],
                       "score": r["score"], "status": r["status"], "time": r["created"]} for r in rows]}


@app.get("/api/assess/{aid}")
def progress(aid: str):
    a = db.get_assessment(aid)
    if not a:
        return JSONResponse({"error": "not found"}, 404)
    stage = json.loads(a["stage"]) if a["stage"] else {"idx": 0, "stage": "init", "detail": ""}
    return {"id": aid, "status": a["status"], "stage_idx": stage.get("idx", 0), "stage": stage,
            "company": a["company_name"], "stages": STAGES}


@app.get("/api/assess/{aid}/report")
def get_report(aid: str):
    a = db.get_assessment(aid)
    if not a or not a["report"]:
        return JSONResponse({"error": "not ready"}, 404)
    return json.loads(a["report"])


@app.post("/api/assess/{aid}/confirm")
async def confirm(aid: str, category: str = Form(...)):
    a = db.get_assessment(aid)
    if not a:
        return JSONResponse({"error": "not found"}, 404)
    rep = json.loads(a["report"]) if a["report"] else {}
    if rep.get("status") == "need_classify":
        n = rep.get("n", {})
        # 从归档文件重新取文本
        dp = os.path.join(UPLOAD_DIR, aid)
        all_text = ""
        for fn in os.listdir(dp):
            pf = parser.parse_file(os.path.join(dp, fn), fn)
            all_text += parser.full_text(pf) + "\n"
        evaluation = scorer.evaluate(category, n)
        gaps = gap.detect(n, category)
        verify_results = verifier.verify(n, all_text, category)
        rep = report_builder.build_report(aid, a["company_name"], category,
                                          {"confidence": 100.0, "reason": "人工确认"}, n, evaluation, gaps,
                                          {}, verify_results, [], [])
        rep["llm_mode"] = "人工分类确认"
        db.set_report(aid, json.dumps(rep, ensure_ascii=False))
        db.execute("UPDATE assessments SET score=?, grade=?, category=?, category_confidence=100, category_confirmed_by_user=1, status='done' WHERE id=?",
                   (evaluation["card"]["total"], evaluation["verdict_name"], category, aid))
        db.update_stage(aid, 8, json.dumps({"stage": "完成", "detail": "人工分类后完成评估"}, ensure_ascii=False))
    return {"ok": True}


@app.post("/api/assess/{aid}/supplement")
async def supplement(aid: str, files: list[UploadFile] = File(...)):
    a = db.get_assessment(aid)
    if not a:
        return JSONResponse({"error": "not found"}, 404)
    rep = json.loads(a["report"]) if a["report"] else {}
    if not rep.get("block_verdict"):
        return JSONResponse({"error": "评估未完成"}, 400)
    dp = os.path.join(UPLOAD_DIR, aid)
    n_old = rep.get("block_extract", {}).get("normalized", {})
    category = rep["block_verdict"]["category"]
    # 解析补传文件并增量提取
    added = {}
    supp_files = []
    for f in files:
        path = os.path.join(dp, "supp_" + f.filename)
        with open(path, "wb") as out:
            shutil.copyfileobj(f.file, out)
        pf = parser.parse_file(path, f.filename)
        db.add_supplement(aid, f.filename, {"pages": len(pf.pages)})
        supp_files.append({"filename": f.filename, "parsed": pf})
    supp_extracted, _ = extractor.extract(supp_files)
    for field, item in supp_extracted.items():
        if isinstance(item, dict) and item.get("value") is not None:
            added[field] = item["value"]
    # 合并：新值覆盖缺失字段（已有人工纠正的不覆盖）
    n_new = dict(n_old)
    for k, v in added.items():
        if n_old.get(k) is None:
            n_new[k] = v
    # 增量重算派生指标（增速/跑道/现金收入比）
    if n_new.get("revenue_growth") is None and n_new.get("revenue_prev") and n_new.get("revenue"):
        n_new["revenue_growth"] = round((n_new["revenue"] - n_new["revenue_prev"]) / n_new["revenue_prev"] * 100, 2)
    if n_new.get("runway_months") is None and n_new.get("cash_balance") and n_new.get("monthly_burn"):
        n_new["runway_months"] = round(n_new["cash_balance"] / n_new["monthly_burn"], 1)
    if n_new.get("cash_ratio") is None and n_new.get("cash_received") and n_new.get("revenue"):
        n_new["cash_ratio"] = round(n_new["cash_received"] / n_new["revenue"] * 100, 2)
    # 重跑评估（2 秒级）
    evaluation = scorer.evaluate(category, n_new)
    gaps = gap.detect(n_new, category)
    dp2 = os.path.join(UPLOAD_DIR, aid)
    all_text = ""
    for fn in os.listdir(dp2):
        pf = parser.parse_file(os.path.join(dp2, fn), fn)
        all_text += parser.full_text(pf) + "\n"
    verify_results = verifier.verify(n_new, all_text, category)
    old_total = rep["block_verdict"]["total"]
    rep2 = report_builder.build_report(aid, a["company_name"], category,
                                       {"confidence": rep["block_verdict"]["category_confidence"], "reason": "补数后重算"},
                                       n_new, evaluation, gaps,
                                       rep.get("block_files", {}).get("tree", {}), verify_results,
                                       rep.get("block_files", {}).get("conflicts", []),
                                       rep.get("block_files", {}).get("files", []))
    rep2["supplement_diff"] = {"old_total": old_total, "new_total": evaluation["card"]["total"],
                               "fields_added": list(added.keys())}
    rep2["llm_mode"] = rep.get("llm_mode", "regex")
    db.set_report(aid, json.dumps(rep2, ensure_ascii=False))
    db.execute("UPDATE assessments SET score=?, grade=? WHERE id=?",
               (evaluation["card"]["total"], evaluation["verdict_name"], aid))
    return {"ok": True, "diff": rep2["supplement_diff"]}


@app.get("/api/meta")
def meta():
    return {"rules_version": rules.RULES_VERSION, "released": rules.RELEASED,
            "case_count": len(db.all_cases()),
            "llm": "双通道（LLM+正则交叉验证）" if extractor.llm_available() else "降级模式（正则单通道）",
            "categories": [c["name"] for c in rules.CATEGORIES.values()]}


# 静态前端
FE = os.path.join(os.path.dirname(__file__), "..", "frontend")
app.mount("/", StaticFiles(directory=FE, html=True), name="fe")
